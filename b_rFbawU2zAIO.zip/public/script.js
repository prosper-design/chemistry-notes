// Mobile Menu Toggle
const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
const navLinks = document.querySelector('.nav-links');

if (mobileMenuBtn && navLinks) {
  mobileMenuBtn.addEventListener('click', () => {
    navLinks.classList.toggle('active');
  });
}

// Notes Page - Topic Navigation
const topicLinks = document.querySelectorAll('.topic-list a');
const noteSections = document.querySelectorAll('.note-section');

if (topicLinks.length > 0 && noteSections.length > 0) {
  // Hide all sections except the first one
  noteSections.forEach((section, index) => {
    if (index !== 0) {
      section.style.display = 'none';
    }
  });

  topicLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      
      // Remove active class from all links
      topicLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');

      // Get target section ID
      const targetId = link.getAttribute('href').substring(1);

      // Hide all sections, show target
      noteSections.forEach(section => {
        if (section.id === targetId) {
          section.style.display = 'block';
        } else {
          section.style.display = 'none';
        }
      });

      // Scroll to top of content on mobile
      if (window.innerWidth < 768) {
        document.querySelector('.note-content').scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
}

// Quiz Data
const quizQuestions = [
  {
    question: "What is the atomic number of Carbon?",
    options: ["4", "6", "8", "12"],
    correct: 1
  },
  {
    question: "Which subatomic particle has a negative charge?",
    options: ["Proton", "Neutron", "Electron", "Nucleus"],
    correct: 2
  },
  {
    question: "What type of bond is formed when electrons are shared between atoms?",
    options: ["Ionic bond", "Covalent bond", "Metallic bond", "Hydrogen bond"],
    correct: 1
  },
  {
    question: "Which group in the periodic table contains the noble gases?",
    options: ["Group 1", "Group 7", "Group 17", "Group 18"],
    correct: 3
  },
  {
    question: "What is the pH of a neutral solution?",
    options: ["0", "7", "10", "14"],
    correct: 1
  },
  {
    question: "How many moles are in 6.022 × 10²³ particles?",
    options: ["0.5 moles", "1 mole", "2 moles", "6.022 moles"],
    correct: 1
  },
  {
    question: "Which element is the most electronegative?",
    options: ["Oxygen", "Nitrogen", "Fluorine", "Chlorine"],
    correct: 2
  },
  {
    question: "What is the product of an acid-base neutralization reaction?",
    options: ["Only water", "Only salt", "Water and salt", "Carbon dioxide"],
    correct: 2
  },
  {
    question: "Which type of reaction is: 2H₂ + O₂ → 2H₂O?",
    options: ["Decomposition", "Synthesis", "Single replacement", "Double replacement"],
    correct: 1
  },
  {
    question: "Isotopes of an element have different numbers of:",
    options: ["Protons", "Electrons", "Neutrons", "Valence electrons"],
    correct: 2
  }
];

// Quiz State
let currentQuestion = 0;
let selectedAnswers = new Array(quizQuestions.length).fill(null);
let quizCompleted = false;

// Quiz Elements
const quizCard = document.getElementById('quiz-card');
const quizResult = document.getElementById('quiz-result');
const questionContainer = document.getElementById('question-container');
const questionNumber = document.getElementById('question-number');
const questionText = document.getElementById('question-text');
const optionsList = document.getElementById('options-list');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');
const progressFill = document.getElementById('progress-fill');
const progressText = document.getElementById('progress-text');
const resultScore = document.getElementById('result-score');
const resultMessage = document.getElementById('result-message');
const retryBtn = document.getElementById('retry-btn');

// Initialize Quiz
function initQuiz() {
  if (!quizCard) return;
  
  currentQuestion = 0;
  selectedAnswers = new Array(quizQuestions.length).fill(null);
  quizCompleted = false;
  
  if (quizResult) quizResult.style.display = 'none';
  if (questionContainer) questionContainer.style.display = 'block';
  if (document.querySelector('.quiz-actions')) {
    document.querySelector('.quiz-actions').style.display = 'flex';
  }
  
  renderQuestion();
}

// Render Current Question
function renderQuestion() {
  if (!questionNumber || !questionText || !optionsList) return;
  
  const question = quizQuestions[currentQuestion];
  
  questionNumber.textContent = `Question ${currentQuestion + 1}`;
  questionText.textContent = question.question;
  
  // Generate options
  optionsList.innerHTML = question.options.map((option, index) => {
    const letters = ['A', 'B', 'C', 'D'];
    const isSelected = selectedAnswers[currentQuestion] === index;
    return `
      <div class="option ${isSelected ? 'selected' : ''}" data-index="${index}">
        <span class="option-marker">${letters[index]}</span>
        <span class="option-text">${option}</span>
      </div>
    `;
  }).join('');

  // Add click handlers to options
  document.querySelectorAll('.option').forEach(option => {
    option.addEventListener('click', () => selectOption(parseInt(option.dataset.index)));
  });

  // Update navigation buttons
  if (prevBtn) prevBtn.disabled = currentQuestion === 0;
  if (nextBtn) {
    nextBtn.textContent = currentQuestion === quizQuestions.length - 1 ? 'Finish' : 'Next';
    nextBtn.innerHTML = currentQuestion === quizQuestions.length - 1 
      ? `Finish <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`
      : `Next <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/><path d="M12 5l7 7-7 7"/></svg>`;
  }

  // Update progress
  updateProgress();
}

// Select Option
function selectOption(index) {
  selectedAnswers[currentQuestion] = index;
  
  // Update visual selection
  document.querySelectorAll('.option').forEach((option, i) => {
    option.classList.toggle('selected', i === index);
  });
}

// Update Progress Bar
function updateProgress() {
  const answered = selectedAnswers.filter(a => a !== null).length;
  const percentage = (answered / quizQuestions.length) * 100;
  
  if (progressFill) progressFill.style.width = `${percentage}%`;
  if (progressText) progressText.textContent = `${answered} / ${quizQuestions.length}`;
}

// Navigate to Previous Question
function previousQuestion() {
  if (currentQuestion > 0) {
    currentQuestion--;
    renderQuestion();
  }
}

// Navigate to Next Question or Finish
function nextQuestion() {
  if (currentQuestion < quizQuestions.length - 1) {
    currentQuestion++;
    renderQuestion();
  } else {
    showResults();
  }
}

// Show Quiz Results
function showResults() {
  quizCompleted = true;
  
  // Calculate score
  let correct = 0;
  selectedAnswers.forEach((answer, index) => {
    if (answer === quizQuestions[index].correct) {
      correct++;
    }
  });
  
  const percentage = Math.round((correct / quizQuestions.length) * 100);
  
  // Hide question, show result
  if (questionContainer) questionContainer.style.display = 'none';
  if (document.querySelector('.quiz-actions')) {
    document.querySelector('.quiz-actions').style.display = 'none';
  }
  if (quizResult) quizResult.style.display = 'block';
  
  // Update result display
  if (resultScore) resultScore.textContent = `${percentage}%`;
  if (resultMessage) {
    if (percentage >= 90) {
      resultMessage.textContent = "Excellent! You are a chemistry master!";
    } else if (percentage >= 70) {
      resultMessage.textContent = "Great job! Keep up the good work!";
    } else if (percentage >= 50) {
      resultMessage.textContent = "Good effort! Review the notes to improve.";
    } else {
      resultMessage.textContent = "Keep practicing! Check the notes for help.";
    }
  }
  
  // Update progress to 100%
  if (progressFill) progressFill.style.width = '100%';
  if (progressText) progressText.textContent = `${quizQuestions.length} / ${quizQuestions.length}`;
}

// Event Listeners
if (prevBtn) prevBtn.addEventListener('click', previousQuestion);
if (nextBtn) nextBtn.addEventListener('click', nextQuestion);
if (retryBtn) retryBtn.addEventListener('click', initQuiz);

// Initialize quiz on page load
document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('quiz-card')) {
    initQuiz();
  }
});

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const targetId = this.getAttribute('href');
    if (targetId === '#') return;
    
    const targetElement = document.querySelector(targetId);
    if (targetElement) {
      e.preventDefault();
      targetElement.scrollIntoView({ behavior: 'smooth' });
    }
  });
});
